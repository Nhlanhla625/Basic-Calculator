run:
===SUM===
Please enter first number: 24
Please enter second number: 12
Our sum is: 36

===SUBTRACT===
Please enter first number: 24
Please enter second number: 12
Our subtraction is: 12

===MUTLIPLY===
Please enter first number: 24
Please enter second number: 12
Our multiplication is: 288

===DIVIDE===
Please enter first number: 24
Please enter second number: 12
Our division is: 2

===MODULO===
Please enter first number: 24
Please enter second number: 12
Our modulo is: 0
BUILD SUCCESSFUL (total time: 30 seconds)
